%% Parameters for Optimization
clear all ; clc ; close all ; 
s = tf('s');
Ts = 1; % Sampling Time  
Ho = 50; % Optimization Horizon (in number of samples)
%% Simulation Time Definition
Tmax = 4000;
t = 0:Ts:Tmax;
%% System to Control
s = tf('s');

% %Functions W/O delays 
% 
% p11=tf([-0.58],[83 1]);
% % check this unusual delays (are casting the tf into a ss model)
% p12=tf([1],[125 1])*tf([1],[195 1])+tf([0.97],[24375 320 1]);
% p13=tf([1],[20 1])*tf([1],[92 1])+tf([0.67],[1840 112 1]);
% 
% p14=tf([0.5], [18 1]);
% p21=tf([0.62],[123 1]);
% p22=tf([-1.75],[118 1]);
% p23=tf([0.51],[81 1]);
% p24=tf([0.64],[137 1]);
% p31=tf([2.61],[110 1]);
% p32=tf([9.52],[98 1]);
% p33=tf([2.83],[128 1]);
% p34=tf([2.81],[108 1]);
% p41=tf([1e-3],[150 1])*tf([1],[1 0]);
% p42=tf([0.011],[100 1])*tf([1],[1 0]);
% p43=tf([0.032],[1 0]);
% p44=tf([-0.031],[1 0]);

%Functions W. delays 
p11=tf([-0.58],[83 1],'InputDelay',41);
%check this unusual delays (are casting the tf into a ss model)
p12=2*( tf([0.97],[24375 320 1],'InputDelay',(40))+tf([0.97*1.08],[24375 320 1],'InputDelay',(40+232)) );
p13=tf([0.67],[1840 112 1],'InputDelay',(8))+tf([0.67*1.07],[1840 112 1],'InputDelay',(8+214));
%
p14=tf([0.5], [18 1], 'InputDelay',2);
p21=tf([0.62],[123 1]);
p22=tf([-1.75],[118 1]);
p23=tf([0.51],[81 1], 'InputDelay',87)*tf([1], [182 1]);
p24=tf([0.64],[137 1],'InputDelay',9);
p31=tf([0.5],[110 1], 'InputDelay',45);
p32=tf([2.08],[98 1],'InputDelay',93)*tf([1], [137 1]);
p33=tf([1.2],[128 1],'InputDelay',8);
p34=tf([1.09],[108 1],'InputDelay',5);
p41=tf([0.000004],[150 1],'InputDelay',30)*tf([1],[1 0]);
p42=tf([0.000012],[100 1],'InputDelay',30)*tf([1],[1 0]);
p43=tf([0.000004],[1 0]);
p44=tf([-0.000025],[1 0]);

Pspm=[p11 p12 p13 p14;
      p21 p22 p23 p24;
      p31 p32 p33 p34;
      p41 p42 p43 p44];

Ts=1; 
sys_d=c2d(Pspm,Ts)
sys_ss = ss(sys_d);

A = sys_ss.A;
B = sys_ss.B;
C = sys_ss.C;
D = sys_ss.D;

Ly = size(C,1); % Number of lines in the output vector
Lu = size(B,2); % Number of lines in the input vector
Lz = size(A,2); % Number of lines in the state vector
%% Yref Definition
yref_1 = [2*1/(1+100*s)+70 ; 2*1/(1+100*s)+80 ; 2*1/(1+100*s)+140; 0.8*1/(1+100*s)+1];
% yref_1 = [69*1/(1+100*s); 84*1/(1+100*s); 140*1/(1+100*s); 0.8*1/(1+100*s)];
yref = step(yref_1,t);

% yref = [69*ones(length(t),1), 84*ones(length(t),1), 0.8*ones(length(t),1), 150*ones(length(t),1)];

%H = 1/(1+s + 5*s^2);
%H = 1/(1+s^2);

yref_opt = reshape(yref',Ly*length(yref),1);
%% Generation of Optimization Matricies 

%INPUTS: 
%feed rate
%mill feed water flow rate
%sump dilution water flow rate
%pump speed

%OUTPUTS:  
%[product particle size  ,  mill solids concentration  ,circulating load,  sump level]

% Constraints on Input/Output
umax = [80 15 45 50]';
umin = [65 2 5 35]';
  
ymax = [100 100 350 2.4]';
ymin = [0       0      0       0]';

% Reconstruction of yref to make the reference 
% signal compatible with the optimization algorithm

% Weight Matricies
Q = diag([1000 1 1 1]); % Weight on yref - y
R = 0.000001*eye(Lu); % Weight on u(i+1) - u(i)

[M,P,V,H,f,T] = ControlOptimizationConstantMatriciesWConstraints(A,B,C,D,Q,R,Ho-1,Ly,Lu);
save ControlOptimizationConstantMatricies M P V H f T
%% MPC simulation 
load ControlOptimizationConstantMatricies.mat

u = zeros(Lu,length(yref)); % Matrice that allows us to record the consecutive values of the input 
u(1:end ,1 ) = [70 2 5 35] ;  
% umax = [80 15 45  50]';

y = zeros(Ly,length(yref)); % Matrice that allows us to record the consecutive values of the output
y(1:end ,1 ) =[70 ; 80 ;140; 1]; 

z = zeros(Lz,length(yref)); % Matrice that allows us to record the consecutive values of the system states 
z(1:end ,1) =pinv(C)*y(1:end ,1) ;   %inv((eye(size(A))-A))*(B)*u(1:end ,1) ;

U = zeros(Lu,Ho);

for k=1:(length(yref_opt)/Ly - Ho + 1)
%for k=1:200
z(1:end,k+1) = A*z(1:end,k) + B*u(1:end,k);
y(1:end,k) = C*z(1:end,k) + D*u(1:end,k);
U = QuadraticOptimalControlSolver(M,P,V,H,f,T,yref_opt(Ly*(k-1)+1:Ly*(k-1)+Ly*Ho),u(1:end,k),z(1:end,k),Ho-1,ymax,ymin,Ly,Lu,umax,umin);
u(1:end,k+1) = U(1:end,2);
k
end
 
figure(1)
plot(t,y,'*',t,yref);
title("Comparison between yref and the optimized output");
legend('particle size','solid concentration','sump level' ...
    ,'circulating load', 'yref particle size','yref solid concentration','yref sump level' ...
    ,'yref circulating load')

figure(2)
plot(t,u);
legend('feed rate','mill feed water flow rate','sump dilution water flow rate' ...
    ,'pump speed')
title("Input Control Signal");


figure(3)
plot(t,y'-yref);